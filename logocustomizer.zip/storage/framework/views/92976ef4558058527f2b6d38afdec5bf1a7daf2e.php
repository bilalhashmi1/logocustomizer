<FOOTER>
  <div class="container">
      <div class="row">
          <div class="col-lg-12 text-center">
              <button class="btn btn-primary">SAVE LOGO & CONTINUE</button>
          </div>
      </div>
  </div>
</footer><?php /**PATH E:\Apex Viewers\Kapoor\logocustomizer\resources\views/layouts/site/includes/footer.blade.php ENDPATH**/ ?>