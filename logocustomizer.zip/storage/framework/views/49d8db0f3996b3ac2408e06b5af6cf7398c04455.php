<header>
    <div class="container-fluid">
        <div class="row">			
            <div class="col-lg-2 text-center">	
                <a class="navbar-brand" href="#"><img class="img-responsive" src="<?php echo e(asset('/site/img/logo.png')); ?>" alt="" /></a>
            </div>
            <div class="col-lg-4 top-buttonmargin tryanotherLogo">				
                <button class="btn btn-primary1"><< TRY ANOTHER LOGO</button>
            </div>
            <div class="col-lg-6 top-buttonmargin red-topBtn text-center">	
                <button class="btn btn-primary"><img class="img-responsive" src="<?php echo e(asset('/site/img/ic-view.png')); ?>" alt="" /> PREVIEW</button> <button class="btn btn-primary">SAVE LOGO & CONTINUE</button>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</header><?php /**PATH E:\Apex Viewers\Kapoor\Logo-maker\resources\views/layouts/site/includes/navbar.blade.php ENDPATH**/ ?>